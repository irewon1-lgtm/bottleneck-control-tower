1) Unzip ALL files to a short new folder.
2) Double-click START_ALL.bat.
3) Keep laptop powered, sleep disabled, and ventilated.
4) Work is locally checkpointed; rerun START_ALL.bat to resume if interrupted.
5) When done, open OPEN_RESULTS.bat and upload BCT_FULLSCAN_REPORT.zip.
6) GitHub is read-only. All AI calls use locally installed qwen3.5:9b; no paid API.
7) The first pass may take hours or days and cannot certify BCT FULL or S1/S2/S3.
