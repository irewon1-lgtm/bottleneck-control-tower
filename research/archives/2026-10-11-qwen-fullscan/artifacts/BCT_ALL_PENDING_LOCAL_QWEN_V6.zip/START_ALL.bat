@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0."
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
echo.
echo BCT FULL UNRESOLVED SCAN - FREE LOCAL QWEN 9B
echo GitHub READ ONLY / Paid AI API: 0 / Existing BCT data untouched
echo NOTE: CPU scanning may take many hours or days.
echo NOTE: Keep laptop plugged in and sleep mode OFF.
echo.
where py >nul 2>nul
if errorlevel 1 goto USING_PYTHON
py -3 --version >nul 2>nul
if errorlevel 1 goto USING_PYTHON
set "PYRUN=py -3"
goto PREFLIGHT
:USING_PYTHON
where python >nul 2>nul
if errorlevel 1 goto PYTHON_NOT_FOUND
python --version >nul 2>nul
if errorlevel 1 goto PYTHON_NOT_FOUND
set "PYRUN=python"
:PREFLIGHT
echo Checking offline safety tests first...
%PYRUN% -m unittest test_fullscan -q
if errorlevel 1 goto TEST_FAILED
echo.
echo PASS: offline tests. The complete frozen unresolved queue will be scanned.
echo Ollama will auto-start if installed and not already running.
echo.
%PYRUN% -u "%~dp0bct_fullscan.py"
set "RC=%ERRORLEVEL%"
goto END
:TEST_FAILED
echo BLOCKED: offline QA failed. No live fetch attempted.
set "RC=1"
goto END
:PYTHON_NOT_FOUND
echo BLOCKED: Python 3.10 or later is required. It was installed during V5 on this laptop.
set "RC=2"
:END
echo.
echo Output: %LOCALAPPDATA%\BCTpilot\fullscan
echo When complete, upload BCT_FULLSCAN_REPORT.zip from the output folder.
if not "%RC%"=="0" echo PAUSED / BLOCKED. Restart START_ALL.bat to resume without resetting the frozen plan.
pause
exit /b %RC%
