#!/usr/bin/env python3
"""BCT complete unresolved-version inventory and read-only local advisory scan.

There are deliberately ZERO GitHub write methods, keys, paid-model endpoints,
production review patches, and S-stage assignments in this package.
Source versions and old hash identity are never silently rebound to newly
fetched article bodies. The script does not claim official FULL, S3 or EARLY.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict, deque
from contextlib import contextmanager
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
import shutil
import subprocess
from pathlib import Path
import re
import sys
import time
import traceback
from urllib.parse import urlsplit
import zipfile

import bct_local_pilot as base
import bct_prestore_verify as v4
import bct_batch100 as v5

VERSION = 'bct-readonly-unresolved-v6'
READER_VERSION = 'bct-v33-reader-1'
MODEL = 'qwen3.5:9b'
ROOT = base.OUTPUT_DIR / 'fullscan'
PLAN = 'frozen-unresolved-plan.json'
JOURNAL = 'url-attempts.jsonl'
SUMMARY = 'latest-summary.json'
REVIEW = 'needs-review.json'
REPORT = 'BCT_FULLSCAN_REPORT.zip'
MAX_ATTEMPTS_PER_URL = 2
HOST_INTERVAL_SECONDS = 3.0
FINAL_DISPOSITIONS = {'CHANGE','RELIEF','DEEP_NEEDED','IRRELEVANT','DATA_INSUFFICIENT'}
URL_SUCCESS = {'LOCAL_PRESTORE_TECH_QA_PASS','SEMANTIC_RECALL_HOLD'}
URL_TERMINAL = URL_SUCCESS | {'SOURCE_QA_HOLD','PAYWALL_OR_LOGIN','SOURCE_TOO_LONG','SOURCE_HOST_BLOCKED','HOST_POLICY_HOLD','INVALID_URL','URL_MISSING'}
# Title-based signals are LOW-confidence navigation hints only, never evidence.
TITLE_PATTERNS = {
    'DEMAND': re.compile(r'\b(?:orders?|demand|offtake|contracts?(?:\s+awards?)?|procurement|bookings|backlog)\b',re.I),
    'CONSTRAINT': re.compile(r'\b(?:shortages?|delays?|bottlenecks?|supply disruptions?|shutdowns?|qualification hurdles?)\b',re.I),
    'CAPACITY_LEAD_TIME': re.compile(r'\b(?:capacity|expand(?:s|ed|ing)?|expansion|production|manufacturing|megawatts?|gigawatts?|facility)\b',re.I),
    'TIMING': re.compile(r'\b(?:by|before|until|through)\s+20\d{2}\b|\b(?:lead.times?|delivery windows?)\b',re.I),
    'RELIEF': re.compile(r'\b(?:restart|commissioning|ramp.up|production begins|approved expansion|relief)\b',re.I),
}


def title_only_hints(value):
    title=value if isinstance(value,str) else ''
    return [name for name,pattern in TITLE_PATTERNS.items() if pattern.search(title)]



def ensure_ollama(root):
    """Start existing local Ollama automatically if not listening; never download a model."""
    try:
        return base.ollama_model(MODEL)
    except RuntimeError:
        pass
    binary=shutil.which('ollama')
    if not binary and os.name=='nt':
        options=[Path(os.environ.get('LOCALAPPDATA',''))/'Programs'/'Ollama'/'ollama.exe',
                 Path(os.environ.get('PROGRAMFILES',''))/'Ollama'/'ollama.exe']
        binary=next((str(x) for x in options if x.is_file()),None)
    if binary is None:
        raise RuntimeError('OLLAMA_NOT_INSTALLED_OR_NOT_ON_PATH; install/launch Ollama first')
    root.mkdir(parents=True,exist_ok=True)
    with (root/'ollama-autostart.log').open('ab') as log:
        flags=getattr(subprocess,'DETACHED_PROCESS',0) | getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
        kwargs={'creationflags':flags} if os.name=='nt' else {'start_new_session':True}
        subprocess.Popen([binary,'serve'],stdout=log,stderr=log,stdin=subprocess.DEVNULL,**kwargs)
    for i in range(20):
        time.sleep(1.5)
        try:
            return base.ollama_model(MODEL)
        except RuntimeError:
            continue
    raise RuntimeError('OLLAMA_AUTOSTART_FAILED; check Ollama installation and local port 11434')


@contextmanager
def process_lock(root):
    """Kernel-held lock released even if the laptop process crashes."""
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    path=root/'RUNNING.lock'
    with path.open('a+b') as out:
        try:
            if os.name=='nt':
                import msvcrt
                out.seek(0)
                msvcrt.locking(out.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(out.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except (OSError,PermissionError) as exc:
            raise RuntimeError('BCT_FULLSCAN_ALREADY_RUNNING') from exc
        try:
            out.seek(0)
            out.truncate(0)
            out.write(f'PID={os.getpid()}\nSTARTED={utcnow()}\n'.encode('ascii'))
            out.flush();os.fsync(out.fileno())
            yield
        finally:
            if os.name=='nt':
                import msvcrt
                out.seek(0);msvcrt.locking(out.fileno(),msvcrt.LK_UNLCK,1)
            else:
                import fcntl
                fcntl.flock(out.fileno(),fcntl.LOCK_UN)


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _record_key(row):
    # The authoritative unresolved-set key used by BCT queue_summary.
    return (row.get('document_id'), row.get('body_sha256') or row.get('source_version'))


def _status(value):
    return {'BODY_OK':'PARTIAL','BODY_UNAVAILABLE':'UNAVAILABLE'}.get(value,value or 'UNAVAILABLE')


def version_records(candidates):
    """Equivalent version expansion to src/bct/future_review.py::_records."""
    results=candidates.get('results',{})
    if not isinstance(results,dict):raise ValueError('MALFORMED_CANDIDATE_RESULTS')
    for document_id,record in results.items():
        if not isinstance(record,dict):raise ValueError('MALFORMED_RECORD')
        current=record.get('current_body_sha256') or record.get('body_sha256')
        versions=record.get('versions',{})
        versions=versions if isinstance(versions,dict) else {}
        hashes=list(versions)
        if current and current not in hashes:hashes.append(current)
        for digest in hashes:
            version=versions.get(digest,{})
            if not isinstance(version,dict):raise ValueError('MALFORMED_VERSION')
            version=dict(version)
            if digest==current: version={**record,**version}
            if isinstance(version.get('screening'),dict):version.update(version['screening'])
            yield {**version,'document_id':document_id,'body_sha256':digest,
                   'url':record.get('url'),'title':record.get('title'),
                   'body_status':_status(version.get('body_status')),
                   'queue_entered_at': version.get('queue_entered_at') or record.get('queue_entered_at') or record.get('collected_at'),
                   'source_version':version.get('source_version') or record.get('source_version')}
        if not hashes or _status(record.get('body_status'))=='UNAVAILABLE':
            yield {**record,'document_id':document_id,'body_sha256':None,
                   'body_status':'UNAVAILABLE',
                   'queue_entered_at':record.get('queue_entered_at') or record.get('collected_at')}


def failure_index(tracking):
    runs=tracking.get('runs',{})
    if not isinstance(runs,(dict,list)):raise ValueError('MALFORMED_TRACKING_RUNS')
    index={}
    for run in (runs.values() if isinstance(runs,dict) else runs):
        if not isinstance(run,dict) or run.get('type')!='queue_resolution' or run.get('state')!='FAIL':continue
        if not run.get('reason') or not run.get('evidence') or not run.get('resume_condition'):continue
        key=(run.get('document_id'),run.get('body_sha256') or run.get('source_version'))
        if not key[0]:continue
        if run.get('finished_at','')>=index.get(key,{}).get('finished_at',''):
            index[key]=run
    return index


def coverage(reviews,extent):
    intervals=sorted((r.get('read_start'),r.get('read_end')) for r in reviews
        if all(type(r.get(k)) is int for k in ('read_start','read_end'))
        and 0<=r['read_start']<=r['read_end']<=extent)
    pos=0
    for a,b in intervals:
        if a>pos:break
        pos=max(pos,b)
    return pos


def review_index(tracking):
    reviews=tracking.get('reviews',{})
    if not isinstance(reviews,dict):raise ValueError('MALFORMED_TRACKING_REVIEWS')
    out=defaultdict(list)
    for r in reviews.values():
        if not isinstance(r,dict) or r.get('reader_version')!=READER_VERSION:continue
        out[(r.get('document_id'),r.get('body_sha256'))].append(r)
    return out


def _latest(reviews):
    return max(reviews,key=lambda r:(r.get('reviewed_at',''),r.get('kind')=='deep',r.get('review_id','')))


def _due_index(tracking):
    out=defaultdict(list)
    for ledger in tracking.get('prediction_ledger',{}).values():
        if not isinstance(ledger,dict):continue
        for entry in ledger.get('entries',[]):
            if isinstance(entry,dict) and isinstance(entry.get('next_check_dates'),list):
                out[entry.get('document_id')].extend(d for d in entry['next_check_dates'] if isinstance(d,str))
    return out


def queue_unresolved(candidates,tracking,now=None):
    """BCT v3.3 queue lane semantics; output includes every unresolved *version*.

    Preserves archived failed lanes; completed FULL versions are only included
    when material/deep/data-wait lanes independently still require attention.
    """
    failures=failure_index(tracking)
    ix=review_index(tracking)
    due_index=_due_index(tracking)
    now=now or datetime.now(timezone.utc)
    date=now.date().isoformat()
    lanes=defaultdict(list)
    record_count=0
    for rec in version_records(candidates):
        record_count+=1
        eligible=bool(rec.get('candidate') or rec.get('tracked_matches') or rec['body_status'] in ('PARTIAL','UNAVAILABLE'))
        if not eligible:continue
        key=(rec['document_id'],rec.get('body_sha256'))
        reviews=ix.get(key,[])
        semantic=[r for r in reviews if r.get('kind') in ('quick','deep')]
        chars=rec.get('body_chars')
        if type(chars) is not int or chars<0:chars=0
        end=coverage(semantic,chars)
        complete=bool(rec.get('body_sha256') and chars>0 and end==chars and
                  any(r.get('disposition') in FINAL_DISPOSITIONS and r.get('read_end')==chars for r in semantic))
        access_recs=[r for r in reviews if r.get('kind')=='access']
        if access_recs:
            access=_latest(access_recs).get('access_status')
        else:
            access=rec.get('reaccess_status') or rec.get('access_status')
            if access=='UNAVAILABLE':access='BLOCKED'
        blocked=access in ('BLOCKED','SOURCE_CHANGED')
        item=dict(rec)
        item['resume_at']=end
        item['access_status']=access
        item['local_record_key']=_record_key(item)
        if rec['body_status'] in ('PARTIAL','UNAVAILABLE') or blocked:lanes['material'].append(item)
        if complete:
            lanes['completed'].append(item)
            if semantic:
                terminal=[r for r in semantic if r.get('disposition') in FINAL_DISPOSITIONS]
                if terminal:
                    latest=_latest(terminal)
                    deep=[r for r in semantic if r.get('kind')=='deep']
                    latest_deep=_latest(deep) if deep else None
                    unfinished=bool(latest_deep and latest_deep.get('analysis_complete') is not True)
                    requested=(latest.get('disposition')=='DEEP_NEEDED' and
                         (not latest_deep or latest_deep.get('reviewed_at','')<latest.get('reviewed_at','')))
                    due=any(latest.get('reviewed_at','')[:10]<d<=date for d in due_index.get(rec['document_id'],[]))
                    if unfinished or requested or due:lanes['deep'].append(item)
                    if latest.get('disposition')=='DATA_INSUFFICIENT' or latest.get('candidate_state')=='DATA_WAIT':lanes['data_wait'].append(item)
        elif not blocked and rec.get('body_sha256') and chars>0:
            lanes['quick'].append(item)
    lanes['quick'].sort(key=lambda r:(r.get('queue_entered_at') or '',r['document_id'],r['body_sha256']))

    # Mirror queue_resolution archive: suppress active lane but PRESERVE failed.
    archived={}
    for lane in ('quick','material','deep','data_wait'):
        active=[]
        for item in lanes[lane]:
            key=item['local_record_key']
            fail=failures.get(key)
            recovered=False
            if fail:
                recovered=any(r.get('kind')=='access' and r.get('access_status')=='AVAILABLE'
                    and r.get('reviewed_at','')>fail.get('finished_at','') for r in ix.get((item['document_id'],item.get('body_sha256')),[]))
            if (not fail or lane not in fail.get('lanes',[]) or recovered or
                    fail.get('source_version')!=item.get('source_version') or
                    fail.get('reader_version')!=READER_VERSION):
                active.append(item)
            else:
                entry=archived.setdefault(key,{**item,'failure_reason':fail.get('reason'),'failed_lanes':[]})
                entry['failed_lanes'].append(lane)
        lanes[lane]=active
    lanes['failed']=list(archived.values())

    unresolved={}
    for lane in ('quick','material','deep','data_wait','failed'):
        for item in lanes[lane]:
            key=item['local_record_key']
            if key not in unresolved:
                unresolved[key]={**item,'lanes':[]}
            unresolved[key]['lanes'].append(lane)
            if lane=='failed':unresolved[key]['failure_reason']=item.get('failure_reason')

    out=[]
    bad_keys=0
    for key,item in unresolved.items():
        url=base.normalized_url(item.get('url'))
        if url is None:bad_keys+=1
        out.append({'document_id':item['document_id'],
                    'body_sha256':item.get('body_sha256'),
                    'source_version':item.get('source_version'),
                    'title':item.get('title'),
                    'url':url,'original_url':item.get('url'),
                    'body_status':item['body_status'],
                    'body_chars':item.get('body_chars'),
                    'candidate_flag':bool(item.get('candidate') or item.get('tracked_matches')),
                    'queue_entered_at':item.get('queue_entered_at'),
                    'original_failure_reason':item.get('failure_reason'),
                    'lanes':sorted(set(item['lanes'])),
                    'resume_at':item.get('resume_at'),
                    'access_status':item.get('access_status')})
    # Predictable selection: prioritize official HIGH-signal watch candidates,
    # then quick actionable items, while preserving every queued item.
    order={'quick':0,'material':1,'deep':2,'data_wait':3,'failed':4}
    out.sort(key=lambda r:(not r['candidate_flag'],
              min(order[x] for x in r['lanes']),r.get('queue_entered_at') or '',r['document_id'],r.get('body_sha256') or r.get('source_version') or ''))
    summaries={k:len(lanes[k]) for k in ('quick','completed','material','deep','data_wait','failed')}
    return out,{'version_records':record_count,'lane_counts':summaries,
                'unresolved_version_identities':len(out),
                'source_urls_missing_or_unsafe':bad_keys,
                'failure_index_records':len(failures),
                'reader_version':READER_VERSION}


def _plan_hash(plan):
    return base.sha(base.json_bytes({k:v for k,v in plan.items() if k!='plan_sha256'}))


def valid_plan(plan):
    if plan.get('version')!=VERSION or plan.get('model')!=MODEL:return False
    if not re.fullmatch(r'[0-9a-f]{40}',str(plan.get('snapshot_commit'))):return False
    items=plan.get('items')
    if not isinstance(items,list) or not items:return False
    keys=[(x['document_id'],x.get('body_sha256') or x.get('source_version')) for x in items]
    if len(set(keys))!=len(keys):return False
    return plan.get('plan_sha256')==_plan_hash(plan)


def obtain_plan(root):
    path=root/PLAN
    if path.exists():
        plan=base.safe_json_file(path)
        if not valid_plan(plan):raise ValueError('FROZEN_PLAN_TAMPERED_OR_CORRUPT')
        return plan
    commit=base.github_head()
    print('GitHub pinned snapshot:',commit,flush=True)
    folder=root/'snapshots'/commit
    candidates=base.get_sidecar(commit,'future-candidates.json',folder)
    tracking=base.get_sidecar(commit,'future-tracking.json',folder)
    items,metrics=queue_unresolved(candidates,tracking)
    if not items:raise RuntimeError('NO_UNRESOLVED_VERSION_IDENTITIES')
    plan={'version':VERSION,'created_at':utcnow(),'model':MODEL,
          'snapshot_commit':commit,'items':items,'selection_metrics':metrics,
          'source_repo':base.REPO,'source_branch':base.BRANCH,
          'BCT_GitHub_writes':False,'official_completion_claims':0}
    plan['plan_sha256']=_plan_hash(plan)
    base.atomic_json(path,plan)
    if not valid_plan(base.safe_json_file(path)):raise RuntimeError('FROZEN_PLAN_READBACK_FAILED')
    return plan


def url_groups(plan):
    groups={}
    for item in plan['items']:
        url=item.get('url')
        if not url:continue
        group=groups.setdefault(url,{'url':url,'records':[],'priority':100})
        group['records'].append(item)
        group['priority']=min(group['priority'],
            0 if item.get('candidate_flag') else 1)
    return groups


def read_journal(path):
    """Fail-closed on corrupt records; only harmless torn final line is ignored."""
    if not path.exists():return []
    rows=[]
    raw=path.read_bytes()
    lines=raw.splitlines(keepends=True)
    for n,line in enumerate(lines,1):
        if not line.strip():continue
        try:
            row=json.loads(line)
        except (json.JSONDecodeError,UnicodeError) as exc:
            if n==len(lines) and not raw.endswith(b'\n'):
                # Interrupted appends may leave an incomplete last line; it is NOT complete.
                return rows
            raise ValueError(f'JOURNAL_CORRUPT_LINE_{n}') from exc
        if row.get('pilot_version')!=VERSION:raise ValueError('JOURNAL_VERSION_CONFLICT')
        rows.append(row)
    return rows


def validate_journal_binding(records,plan):
    expected={x['url'] for x in plan['items'] if x.get('url')}
    for n,row in enumerate(records,1):
        if (row.get('url') not in expected or row.get('snapshot_commit')!=plan['snapshot_commit']
                or row.get('plan_sha256')!=plan['plan_sha256']):
            raise ValueError('JOURNAL_FROZEN_PLAN_MISMATCH_AT_'+str(n))


def latest_journal(rows):
    latest={}
    attempts=Counter()
    for row in rows:
        url=row.get('url')
        if not url:raise ValueError('JOURNAL_URL_MISSING')
        latest[url]=row
        if row.get('execution_started') is True:attempts[url]+=1
    return latest,attempts


def _host(url):
    try:return urlsplit(url).hostname or ''
    except ValueError:return ''


def _temporary(status, reason, http_status=None):
    return status in ('SOURCE_FETCH_ERROR','AI_READ_PARTIAL','LOCAL_EXCEPTION') and (
        http_status in (429,500,502,503,504) or
        status in ('AI_READ_PARTIAL','LOCAL_EXCEPTION') or
        reason in ('TimeoutError','URLError','DNS_RESOLUTION_FAILED','NETWORK_ERROR'))


def balanced_groups(groups):
    """Interleave source hosts to reduce repeated hits to one publisher."""
    priority_buckets=defaultdict(lambda:defaultdict(deque))
    for item in groups.values():
        priority_buckets[item['priority']][_host(item['url'])].append(item)
    result=[]
    for priority in sorted(priority_buckets):
        pools=priority_buckets[priority]
        for host in pools:
            pools[host]=deque(sorted(pools[host],key=lambda r:r['url']))
        hosts=sorted(pools)
        while any(pools.values()):
            for host in hosts:
                if pools[host]:result.append(pools[host].popleft())
    return result


def repair_torn_journal_tail(path):
    """Move truncated final JSON line aside; never lose a valid journal row."""
    if not path.is_file():return False
    raw=path.read_bytes()
    if not raw or raw.endswith(b'\n'):return False
    ending=raw.rsplit(b'\n',1)[-1]
    try:
        json.loads(ending)
    except (ValueError,UnicodeError):
        prefix=raw[:len(raw)-len(ending)]
        quarantine=path.parent/'quarantined-journal-tails'
        quarantine.mkdir(parents=True,exist_ok=True)
        digest=base.sha(ending)
        base.atomic_bytes(quarantine/(digest+'.truncated'),ending)
        base.atomic_bytes(path,prefix)
        return True
    base.atomic_bytes(path,raw+b'\n')
    return True


def _count_read(rows):
    return Counter(x.get('status','UNKNOWN') for x in rows.values())


def make_report(root,plan,rows,*,active=False):
    """All planned *versions* covered in inventory; actual reads are URL-scoped."""
    groups=url_groups(plan)
    statuses=_count_read(rows)
    by_reason=Counter(x.get('original_failure_reason') or 'UNKNOWN' for x in plan['items'])
    record_has_url=Counter(x.get('url') is not None for x in plan['items'])
    pending_urls=[];done_urls=[];deferred_urls=[]
    for url in groups:
        state=rows.get(url)
        if state is None:pending_urls.append(url)
        elif state.get('status') in URL_TERMINAL:done_urls.append(url)
        elif state.get('status') in ('SOURCE_FETCH_ERROR','AI_READ_PARTIAL','LOCAL_EXCEPTION'):
            if state.get('retry_exhausted'):done_urls.append(url)
            else:deferred_urls.append(url)
        else:deferred_urls.append(url)
    technical=[row for row in rows.values() if row.get('status') in URL_SUCCESS]
    needs_review=[]
    for row in technical:
        claims=row.get('claims',[])
        if claims or row.get('semantic_recall')=='REVIEW_REQUIRED':
            needs_review.append({'url':row['url'],'document_versions':len(groups.get(row['url'],{}).get('records',[])),
               'status':row['status'],'article_sha256':row.get('article_sha256'),
               'claims_count':len(claims), 'claims':claims[:18],
               'quantity_hint_examples':row.get('quantity_hint_examples',[])[:6],
               'original_body_versions':[{'document_id':r['document_id'],'source_version':r.get('source_version'),
                              'original_body_sha256':r.get('body_sha256')} for r in groups[row['url']]['records'][:3]],
               'official_bct_full':False,'S1_S2_S3_confirmed':False})
    needs_review.sort(key=lambda x:(-x['claims_count'],x['url']))
    report={'version':VERSION,'generated_at':utcnow(),
      'snapshot_commit':plan['snapshot_commit'],
      'plan_sha256':plan['plan_sha256'],
      'frozen_unresolved_version_count':len(plan['items']),
      'frozen_original_version_lane_counts':plan['selection_metrics']['lane_counts'],
      'unique_safe_article_urls':len(groups),
      'versions_without_safe_source_url':len(plan['items'])-record_has_url[True],
      'source_urls_final_or_held':len(done_urls),
      'source_urls_pending':len(pending_urls),
      'source_urls_deferred_or_retry_pending':len(deferred_urls),
      'source_urls_with_actual_attempt':sum(bool(r.get('actual_fetch_attempted')) for r in rows.values()),
      'version_title_only_weak_signal_count':sum(bool(title_only_hints(x.get('title'))) for x in plan['items']),
      'url_status_counts':dict(statuses),
      'old_failure_reasons':dict(by_reason),
      'local_model_technical_validated_url_count':sum(r.get('status') in URL_SUCCESS for r in rows.values()),
      'model_claims_advisory':sum(len(r.get('claims',[])) for r in rows.values()),
      'evidence_review_items':len(needs_review),
      'model_semantic_accuracy':'UNVERIFIED',
      'BCT_official_full_verified':0,'BCT_S1_S2_S3_verified':0,
      'BCT_GitHub_writes':0,'GitHub_write_connection':'NONE',
      'batch_complete':len(pending_urls)==0 and len(deferred_urls)==0,
      'activity_state':'RUNNING' if active else ('LOCAL_FIRST_PASS_FINISHED' if len(pending_urls)==0 and len(deferred_urls)==0 else 'PAUSED_OR_STOPPED'),
      'meaning':'All unresolved version identities inventoried; one new URL capture cannot certify older stored body versions.'}
    base.atomic_json(root/SUMMARY,report)
    base.atomic_json(root/REVIEW,{'format':'bct-v6-claims-advisory','items':needs_review[:1200],
                                 'omitted_from_export':max(0,len(needs_review)-1200)})
    return report


def export_report(root,plan=None):
    if plan is None:
        p=root/PLAN
        if not p.exists():raise FileNotFoundError('No fullscan plan yet. Run START_ALL.bat first.')
        plan=base.safe_json_file(p)
    if not valid_plan(plan):raise ValueError('EXPORT_FROZEN_PLAN_INTEGRITY_FAILED')
    journal_rows=read_journal(root/JOURNAL)
    validate_journal_binding(journal_rows,plan)
    rows,_=latest_journal(journal_rows)
    report=make_report(root,plan,rows)
    out=root/REPORT
    contents=[SUMMARY,REVIEW,PLAN]
    # Inventory file includes IDs only. No republishing whole copyrighted article bodies.
    inventory=[]
    groups=url_groups(plan)
    for item in plan['items']:
        url=item.get('url')
        row=rows.get(url,{}) if url else {}
        inventory.append({'document_id':item['document_id'],
          'body_sha256':item.get('body_sha256'),'source_version':item.get('source_version'),
          'lanes':item.get('lanes',[]),'original_body_status':item.get('body_status'),
          'original_failure_reason':item.get('original_failure_reason'),
          'url':url,'local_url_status':row.get('status','NOT_YET_ATTEMPTED') if url else 'URL_MISSING_OR_UNSAFE',
          'latest_extracted_body_sha256':row.get('article_sha256'),
          'original_version_exact_match':item.get('body_sha256')==row.get('article_sha256') if row else False,
          'BCT_official_full_approved':False,
          'title_only_weak_hints':title_only_hints(item.get('title')),
          'title_only_hints_are_evidence':False})
    lines=['document_id\told_hash\tsource_version\tlane\tfailure_reason\tlocal_status\turl']
    for item in inventory:
        cells=[item['document_id'],item['body_sha256'] or '',item['source_version'] or '',
               ';'.join(item['lanes']),item.get('original_failure_reason') or '',
               item['local_url_status'],item['url'] or '']
        lines.append('\t'.join(str(c).replace('\n',' ').replace('\r',' ').replace('\t',' ') for c in cells))
    tmp=root/(REPORT+'.temporary')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for file in contents:
            f=root/file
            if f.is_file():z.write(f,arcname=file)
        z.writestr('version-inventory.tsv','\ufeff'+'\n'.join(lines)+'\n')
        z.writestr('version-inventory.json',base.json_bytes(inventory))
        # Smaller aggregate URL table: all source errors with safe bounded details.
        listing=[]
        for url,row in rows.items():
            listing.append({'url':url,'status':row.get('status'),'http_status':row.get('http_status'),
                'hold_reasons':row.get('hold_reasons',[]),'error_type':row.get('reason') or row.get('error_type'),
                'claim_count':len(row.get('claims',[])),'article_sha256':row.get('article_sha256'),
                'technical_full_read':row.get('local_read',{}).get('full_read_verified') is True,
                'original_record_count':len(groups.get(url,{}).get('records',[]))})
        z.writestr('url-results.json',base.json_bytes(listing))
    os.replace(tmp,out)
    return report,out


def scan(root=ROOT,*,max_urls=None,source_fetcher=v4.fetch_public,reader=v4.read_entire_body,
         print_fn=print,now_func=time.time,sleep_func=time.sleep):
    root=Path(root)
    with process_lock(root):
        ensure_ollama(root)
        with v5.v5_reader_scope():
            plan=obtain_plan(root)
            groups=url_groups(plan)
            repair_torn_journal_tail(root/JOURNAL)
            records=read_journal(root/JOURNAL)
            validate_journal_binding(records,plan)
            latest,attempts=latest_journal(records)
            print_fn('BCT ALL READ-ONLY | Qwen',MODEL, '| version records',len(plan['items']),
                     '| unique article URLs',len(groups),flush=True)
            print_fn('Pinned snapshot',plan['snapshot_commit'],'| past finished',len(latest),'| remaining',len(groups)-len(latest),flush=True)
            make_report(root,plan,latest,active=True)
            candidates=balanced_groups(groups)
            last_host={}
            cooldown_until={}
            started_urls=0
            consecutive_model_failures=0
            stop_early=False
            # Every accessible URL is scanned once, with a second bounded pass
            # for transient source/model failures. The batch plan never changes.
            for cycle in (1,2):
                if cycle==2:
                    outstanding=[url for url in groups if url in latest
                        and latest[url].get('status') not in URL_TERMINAL
                        and not latest[url].get('retry_exhausted')]
                    if not outstanding:break
                    due=[cooldown_until.get(_host(url),0) for url in outstanding]
                    soon=min(due) if due else 0
                    if soon>now_func():
                        wait=max(0,soon-now_func())
                        print_fn('Retry cooldown for blocked hosts:',round(wait),'seconds. Existing data saved.',flush=True)
                        # At most two cycles; do not spin on 429.
                        sleep_func(wait)
                    print_fn('Automatic bounded retry pass for',len(outstanding),'URLs',flush=True)
                terminal_hosts=set()
                for group in candidates:
                    url=group['url'];host=_host(url)
                    prior=latest.get(url)
                    if prior and (prior.get('status') in URL_TERMINAL or prior.get('retry_exhausted')):
                        continue
                    if cycle==2 and not prior:
                        # A prior scan skipped the host due to rate limiting.
                        # Test it only if it has not been explicitly blocked.
                        continue
                    if max_urls is not None and started_urls>=max_urls:
                        stop_early=True;break
                    if host in terminal_hosts and not prior:
                        row={'status':'HOST_POLICY_HOLD','url':url,'reason':'HOST_BLOCKED_429_OR_403',
                             'actual_fetch_attempted':False,'execution_started':False,
                             'pilot_version':VERSION,'at':utcnow(),'BCT_GitHub_writes':False,
                             'snapshot_commit':plan['snapshot_commit'],'plan_sha256':plan['plan_sha256']}
                    else:
                        due=cooldown_until.get(host,0)
                        if due>now_func():
                            # A host has explicitly requested a cooldown.
                            # Untouched URLs remain NOT_YET_ATTEMPTED; do not
                            # fabricate a fetch or consider them completed.
                            continue
                        if host in last_host:
                            sleep_func(max(0,HOST_INTERVAL_SECONDS-(time.monotonic()-last_host[host])))
                        last_host[host]=time.monotonic()
                        item=dict(group['records'][0]);item['url']=url
                        try:
                            row=v4._run_one(root,MODEL,item,source_fetcher,reader)
                            v5.examine_model_recall(root,row)
                        except KeyboardInterrupt:
                            print_fn('Interrupted. Restart START_ALL to continue from journal.',flush=True)
                            stop_early=True;break
                        except Exception as exc:
                            row={'status':'LOCAL_EXCEPTION','reason':type(exc).__name__,
                                 'error_message':str(exc)[:180], 'document_id':item['document_id'],
                                 'body_sha256':item.get('body_sha256'),'source_version':item.get('source_version'),
                                 'url':url}
                        row['actual_fetch_attempted']=row.get('status')=='SOURCE_FETCH_ERROR' or isinstance(row.get('http_status'),int)
                        row['execution_started']=True
                        row['pilot_version']=VERSION
                        row['url']=url
                        row['at']=utcnow()
                        row['BCT_GitHub_writes']=False
                        row['snapshot_commit']=plan['snapshot_commit']
                        row['plan_sha256']=plan['plan_sha256']
                        row['versions_sharing_url']=len(group['records'])
                        started_urls+=1
                        status=row.get('status','UNKNOWN')
                        if status=='SOURCE_FETCH_ERROR' and row.get('reason')=='HTTP_403':
                            # Preserve refusal; do not try other URLs from this host
                            # just to evade its access policy.
                            row['status']='SOURCE_HOST_BLOCKED'
                            terminal_hosts.add(host)
                        elif status=='SOURCE_FETCH_ERROR' and row.get('reason') in ('HTTP_429','HTTP_503'):
                            terminal_hosts.add(host)
                            # Respect 429 / unavailable service; never bypass access.
                            cooldown_until[host]=now_func()+3600
                        if status in ('AI_READ_PARTIAL','LOCAL_EXCEPTION'):
                            consecutive_model_failures+=1
                        else:
                            consecutive_model_failures=0
                    if row.get('status') in ('SOURCE_FETCH_ERROR','AI_READ_PARTIAL','LOCAL_EXCEPTION'):
                        row['retry_exhausted']=attempts[url]+int(row.get('execution_started',False))>=MAX_ATTEMPTS_PER_URL
                    base.append_jsonl(root/JOURNAL,row)
                    latest[url]=row
                    if row.get('execution_started'):attempts[url]+=1
                    print_fn(f'[{len(latest)}/{len(groups)}] {row["status"]} | {host}',flush=True)
                    if len(latest)%10==0:
                        make_report(root,plan,latest,active=True)
                    if len(latest)%100==0:
                        export_report(root,plan)
                    if consecutive_model_failures>=3:
                        print_fn('Paused after three consecutive model/local failures; check Ollama.',flush=True)
                        stop_early=True;break
                if stop_early:break
            report,out=export_report(root,plan)
            print_fn('LOCAL RESULTS',str(out),flush=True)
            print_fn('URLs done/held',report['source_urls_final_or_held'],'/',report['unique_safe_article_urls'],
                     '| pending',report['source_urls_pending'],'| retry pending',report['source_urls_deferred_or_retry_pending'],flush=True)
            print_fn('Official BCT completions: 0 | GitHub writes: 0',flush=True)
            return 0 if report['batch_complete'] else 2


def main():
    ap=argparse.ArgumentParser(description='BCT entire unresolved-version read-only Ollama first pass')
    ap.add_argument('--limit-urls',type=int,default=None,help='For safe local diagnostics; default ALL')
    ap.add_argument('--status',action='store_true')
    ap.add_argument('--export',action='store_true')
    ap.add_argument('--root',type=Path,default=ROOT)
    args=ap.parse_args()
    if args.status:
        p=args.root/SUMMARY
        if not p.exists():
            print('Not started. Double-click START_ALL.bat')
        else:
            data=base.safe_json_file(p)
            print('BCT LOCAL READ-ONLY | Frozen versions:',data.get('frozen_unresolved_version_count'))
            print('Distinct URLs:',data.get('unique_safe_article_urls'))
            print('URLs finished/held:',data.get('source_urls_final_or_held'))
            print('Pending:',data.get('source_urls_pending'),'| retry pending:',data.get('source_urls_deferred_or_retry_pending'))
            print('Local model technical QA:',data.get('local_model_technical_validated_url_count'))
            print('Potential evidence claims:',data.get('model_claims_advisory'))
            print('Status:',data.get('activity_state'))
            print('Official BCT completions: 0 | GitHub write: 0')
        return 0
    if args.export:
        report,path=export_report(args.root)
        print(str(path))
        return 0
    return scan(args.root,max_urls=args.limit_urls)


if __name__=='__main__':
    try:sys.exit(main())
    except KeyboardInterrupt:
        print('PAUSED. Restart START_ALL.bat to resume. No GitHub writes.');sys.exit(130)
    except Exception as exc:
        print('BLOCKED:',type(exc).__name__,str(exc)[:260],file=sys.stderr)
        traceback.print_exc(limit=3)
        sys.exit(1)
