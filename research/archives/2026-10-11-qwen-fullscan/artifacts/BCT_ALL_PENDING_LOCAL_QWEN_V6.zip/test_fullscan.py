import contextlib
from datetime import datetime,timezone
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch

import bct_fullscan as f
import bct_local_pilot as b

D=lambda n: f'{n:064x}'


def mkdoc(n,status='FULL',hash=True,candidate=True,url=None,extra=None):
    blob=D(n) if hash else None
    record={'url':url or f'https://example.org/article-{n}','title':f'Article {n}',
            'candidate':candidate,'body_status':status,'body_chars':100,'source_version':f'v{n}',
            'body_sha256':blob,'current_body_sha256':blob}
    if blob: record['versions']={blob:{'body_status':status,'body_chars':100,'source_version':f'v{n}','candidate':candidate}}
    if extra:record.update(extra)
    return record


def review(n,disposition='IRRELEVANT',kind='quick',start=0,end=100,**kw):
    return {'document_id':f'd{n}','body_sha256':D(n),'reader_version':f.READER_VERSION,
        'kind':kind,'read_start':start,'read_end':end,'disposition':disposition,
        'reviewed_at':'2026-10-01T12:00:00+00:00','review_id':f'r{n}-{kind}',**kw}


class TestFullscan(unittest.TestCase):
    def test_only_unfinished_full(self):
        c={'results':{'d1':mkdoc(1),'d2':mkdoc(2)}}
        t={'reviews':{'r1':review(1)},'runs':{}}
        xs,meta=f.queue_unresolved(c,t)
        self.assertEqual([x['document_id'] for x in xs],['d2'])
        self.assertEqual(meta['lane_counts']['quick'],1)
        self.assertEqual(meta['lane_counts']['completed'],1)

    def test_partial_even_if_completed_still_material(self):
        c={'results':{'d1':mkdoc(1,'PARTIAL')}}
        t={'reviews':{'r1':review(1)},'runs':{}}
        xs,meta=f.queue_unresolved(c,t)
        self.assertEqual(len(xs),1)
        self.assertEqual(xs[0]['lanes'],['material'])
        self.assertEqual(meta['lane_counts']['completed'],1)

    def test_datawait_completion_is_unresolved(self):
        c={'results':{'d1':mkdoc(1)}}
        t={'reviews':{'r1':review(1,disposition='DATA_INSUFFICIENT')},'runs':{}}
        xs,meta=f.queue_unresolved(c,t)
        self.assertEqual(xs[0]['lanes'],['data_wait'])

    def test_deep_needed_completion_is_unresolved(self):
        c={'results':{'d1':mkdoc(1)}}
        t={'reviews':{'r1':review(1,disposition='DEEP_NEEDED')},'runs':{}}
        xs,_=f.queue_unresolved(c,t)
        self.assertEqual(xs[0]['lanes'],['deep'])

    def test_coverage_gap_not_completion(self):
        c={'results':{'d1':mkdoc(1)}}
        t={'reviews':{'x':review(1,start=0,end=40),'y':review(1,start=50,end=100,kind='deep')},'runs':{}}
        xs,_=f.queue_unresolved(c,t)
        self.assertEqual(xs[0]['lanes'],['quick'])

    def test_reviews_linked_to_exact_hash(self):
        c={'results':{'d1':mkdoc(1)}}
        r=review(1);r['body_sha256']=D(2)
        xs,_=f.queue_unresolved(c,{'reviews':{'r':r},'runs':{}})
        self.assertEqual(xs[0]['lanes'],['quick'])

    def test_nohash_unavailable(self):
        c={'results':{'d1':mkdoc(1,'UNAVAILABLE',hash=False)}}
        xs,_=f.queue_unresolved(c,{'reviews':{},'runs':{}})
        self.assertEqual(len(xs),1)
        self.assertIn('material',xs[0]['lanes'])

    def test_failed_archived_follows_lane(self):
        c={'results':{'d1':mkdoc(1,'PARTIAL')}}
        fail={'type':'queue_resolution','state':'FAIL','reader_version':f.READER_VERSION,
              'source_version':'v1','document_id':'d1','body_sha256':D(1),
              'reason':'ENVIRONMENT_DNS_RESOLUTION_FAILED','evidence':{'x':1},
              'resume_condition':'New env','lanes':['quick','material'],'finished_at':'2026-10-03'}
        xs,meta=f.queue_unresolved(c,{'reviews':{},'runs':{'fail':fail}})
        self.assertEqual(xs[0]['lanes'],['failed'])
        self.assertEqual(meta['lane_counts']['failed'],1)
        self.assertEqual(xs[0]['original_failure_reason'],'ENVIRONMENT_DNS_RESOLUTION_FAILED')

    def test_blocked_full_is_material_only(self):
        c={'results':{'d1':mkdoc(1,extra={'access_status':'BLOCKED'})}}
        xs,_=f.queue_unresolved(c,{'reviews':{},'runs':{}})
        self.assertEqual(xs[0]['lanes'],['material'])

    def test_old_body_version_not_overwritten(self):
        old=mkdoc(1,'PARTIAL')
        old['versions'][D(2)]={'body_status':'PARTIAL','body_chars':90,'source_version':'prior','candidate':True}
        c={'results':{'d1':old}}
        xs,_=f.queue_unresolved(c,{'reviews':{},'runs':{}})
        self.assertEqual(len(xs),2)
        self.assertEqual({i['body_sha256'] for i in xs},{D(1),D(2)})

    def test_invalid_source_url_is_inventory(self):
        c={'results':{'d1':mkdoc(1,url='http://127.0.0.1/internal')}}
        xs,meta=f.queue_unresolved(c,{'reviews':{},'runs':{}})
        self.assertEqual(len(xs),1)
        self.assertIsNone(xs[0]['url'])
        self.assertEqual(meta['source_urls_missing_or_unsafe'],1)

    def test_same_url_groups_one_fetch(self):
        c={'results':{'d1':mkdoc(1,url='https://example.org/common'),
                      'd2':mkdoc(2,url='https://example.org/common')}}
        xs,_=f.queue_unresolved(c,{'reviews':{},'runs':{}})
        plan={'items':xs}
        groups=f.url_groups(plan)
        self.assertEqual(len(groups),1)
        self.assertEqual(len(next(iter(groups.values()))['records']),2)

    def test_plan_tamper_protect(self):
        plan={'version':f.VERSION,'model':f.MODEL,'snapshot_commit':'a'*40,
              'items':[{'document_id':'x','body_sha256':'digest','url':'https://example.org'}]}
        plan['plan_sha256']=f._plan_hash(plan)
        self.assertTrue(f.valid_plan(plan))
        plan['items'][0]['url']='https://evil.org'
        self.assertFalse(f.valid_plan(plan))

    def test_journal_valid_and_torn_end(self):
        with tempfile.TemporaryDirectory() as root:
            p=Path(root)/'x.jsonl'
            p.write_bytes((json.dumps({'pilot_version':f.VERSION,'url':'https://example.org'})+'\n{"broken":').encode())
            self.assertEqual(len(f.read_journal(p)),1)
            p.write_text('{broken}\n'+json.dumps({'pilot_version':f.VERSION,'url':'https://example.org'})+'\n')
            with self.assertRaises(ValueError):f.read_journal(p)

    def test_report_counts_no_hash_magic(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            item={'document_id':'d1','body_sha256':D(1),'source_version':'s',
                  'url':'https://example.org/1','original_failure_reason':'ENVIRONMENT_DNS_RESOLUTION_FAILED',
                  'body_status':'PARTIAL','lanes':['material'],'candidate_flag':True}
            p={'items':[item],'snapshot_commit':'a'*40,'plan_sha256':'b'*64,
               'selection_metrics':{'lane_counts':{'material':1}}}
            row={'url':item['url'],'status':'LOCAL_PRESTORE_TECH_QA_PASS',
                 'claims':[{'category':'DEMAND','exact_quote':'text'}],
                 'article_sha256':D(2)}
            r=f.make_report(root,p,{item['url']:row})
            self.assertTrue(r['batch_complete'])
            self.assertEqual(r['model_claims_advisory'],1)
            self.assertEqual(r['BCT_official_full_verified'],0)
            self.assertEqual(r['BCT_GitHub_writes'],0)
            self.assertNotIn('qwen_api_key',r)

    def test_report_missing_url_only_inventory(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            item={'document_id':'d1','body_sha256':D(1),'url':None,'lanes':['material']}
            p={'items':[item],'snapshot_commit':'a'*40,'plan_sha256':'b'*64,
               'selection_metrics':{'lane_counts':{'material':1}}}
            r=f.make_report(root,p,{})
            self.assertEqual(r['versions_without_safe_source_url'],1)
            self.assertEqual(r['local_model_technical_validated_url_count'],0)

    def test_export_report_inventory(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            item={'document_id':'d1','body_sha256':D(1),'source_version':'v1','lanes':['material'],
                  'url':'https://example.org/1','body_status':'PARTIAL','original_failure_reason':'FULL_SOURCE_NOT_OBTAINED'}
            p={'items':[item],'snapshot_commit':'a'*40,'plan_sha256':'b'*64,
               'selection_metrics':{'lane_counts':{'material':1}}}
            p.update(version=f.VERSION,model=f.MODEL)
            p['plan_sha256']=f._plan_hash(p)
            f.base.atomic_json(root/f.PLAN,p)
            f.base.append_jsonl(root/f.JOURNAL,{'url':item['url'],'status':'SOURCE_QA_HOLD','pilot_version':f.VERSION,'plan_sha256':p['plan_sha256'],'snapshot_commit':p['snapshot_commit']})
            _,z=f.export_report(root,p)
            import zipfile
            with zipfile.ZipFile(z) as file:
                self.assertEqual(len(json.loads(file.read('version-inventory.json'))),1)
                self.assertEqual(json.loads(file.read(f.SUMMARY))['BCT_GitHub_writes'],0)

    def test_resume_does_not_refetch_terminal(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            item={'document_id':'d1','body_sha256':D(1),'source_version':'v1',
                  'url':'https://example.org/a','candidate_flag':True,'lanes':['quick']}
            plan={'version':f.VERSION,'model':f.MODEL,'items':[item], 'snapshot_commit':'a'*40,
                  'selection_metrics':{'lane_counts':{'quick':1}}}
            plan['plan_sha256']=f._plan_hash(plan)
            f.base.append_jsonl(root/f.JOURNAL,{'url':item['url'],'status':'SOURCE_QA_HOLD','pilot_version':f.VERSION,'snapshot_commit':plan['snapshot_commit'],'plan_sha256':plan['plan_sha256']})
            calls=[]
            with (patch.object(f,'ensure_ollama',return_value=f.MODEL),
                  patch.object(f,'obtain_plan',return_value=plan),
                  patch.object(f.v4,'_run_one',side_effect=lambda *a:calls.append(1)),
                  patch.object(f.v5,'examine_model_recall',side_effect=lambda *a:None)):
                rc=f.scan(root,print_fn=lambda *a,**kw:None)
            self.assertEqual(rc,0)
            self.assertFalse(calls)

    def test_freeze_does_not_replace_existing_plan(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            item={'document_id':'d1','body_sha256':D(1),'source_version':'v1','url':'https://example.org'}
            p={'version':f.VERSION,'model':f.MODEL,'snapshot_commit':'a'*40,'items':[item]}
            p['plan_sha256']=f._plan_hash(p)
            f.base.atomic_json(root/f.PLAN,p)
            with patch.object(f.base,'github_head',side_effect=RuntimeError('SHOULD_NOT_HAPPEN')):
                self.assertEqual(f.obtain_plan(root),p)

    def test_retry_exhausted_on_second_run(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            item={'document_id':'d1','body_sha256':D(1),'source_version':'v1',
                  'url':'https://example.org/a','candidate_flag':True,'lanes':['quick']}
            p={'version':f.VERSION,'model':f.MODEL,'items':[item], 'snapshot_commit':'a'*40,
               'selection_metrics':{'lane_counts':{'quick':1}}}
            p['plan_sha256']=f._plan_hash(p)
            def fail(*args):return {'status':'SOURCE_FETCH_ERROR','reason':'DNS_RESOLUTION_FAILED'}
            with (patch.object(f,'ensure_ollama',return_value=f.MODEL),
                  patch.object(f,'obtain_plan',return_value=p),
                  patch.object(f.v4,'_run_one',side_effect=fail),
                  patch.object(f.v5,'examine_model_recall',side_effect=lambda *a:None)):
                a=f.scan(root,print_fn=lambda *args,**k:None)
                b=f.scan(root,print_fn=lambda *args,**k:None)
            self.assertEqual(a,0)
            self.assertEqual(b,0)
            rows=f.read_journal(root/f.JOURNAL)
            self.assertEqual(len(rows),2)
            self.assertTrue(rows[-1]['retry_exhausted'])

    def test_balances_host_round_robin(self):
        urls=['https://a.org/1','https://a.org/2','https://a.org/3',
              'https://b.org/1','https://b.org/2','https://c.org/1']
        groups={u:{'url':u,'priority':0} for u in urls}
        ordered=f.balanced_groups(groups)
        self.assertEqual(len(ordered),6)
        self.assertEqual([f._host(r['url']) for r in ordered[:3]],['a.org','b.org','c.org'])

    def test_repair_torn_journal_tail(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'attempts.jsonl'
            head=json.dumps({'url':'https://a.org','pilot_version':f.VERSION}).encode()+b'\n'
            p.write_bytes(head+b'{"unfinished":')
            self.assertTrue(f.repair_torn_journal_tail(p))
            self.assertEqual(p.read_bytes(),head)
            quarantine=list((Path(folder)/'quarantined-journal-tails').glob('*'))
            self.assertEqual(len(quarantine),1)
            self.assertEqual(quarantine[0].read_bytes(),b'{"unfinished":')
            self.assertFalse(f.repair_torn_journal_tail(p))

    def test_repair_missing_newline_keeps_valid_row(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'attempts.jsonl'
            p.write_text(json.dumps({'url':'https://a.org','pilot_version':f.VERSION}))
            self.assertTrue(f.repair_torn_journal_tail(p))
            self.assertEqual(len(f.read_journal(p)),1)
            self.assertTrue(p.read_bytes().endswith(b'\n'))

    def test_4000_version_inventory_does_not_drop(self):
        sample={f'd{i}':mkdoc(i,'PARTIAL',url=f'https://a.org/{i//2}') for i in range(1,4200)}
        xs,meta=f.queue_unresolved({'results':sample},{'reviews':{},'runs':{}})
        self.assertEqual(len(xs),4199)
        self.assertEqual(len(f.url_groups({'items':xs})),2100)
        self.assertEqual(meta['unresolved_version_identities'],4199)
    def test_journal_binding_mismatch_fails_closed(self):
        plan={'items':[{'url':'https://example.org'}],'snapshot_commit':'a'*40,'plan_sha256':'b'*64}
        row={'url':'https://example.org','snapshot_commit':'different','plan_sha256':'b'*64}
        with self.assertRaises(ValueError):f.validate_journal_binding([row],plan)
        row['snapshot_commit']='a'*40
        f.validate_journal_binding([row],plan)

    def test_kernel_process_lock_allows_crash_recovery(self):
        with tempfile.TemporaryDirectory() as d:
            with f.process_lock(d):
                with self.assertRaises(RuntimeError):
                    with f.process_lock(d):pass
            with f.process_lock(d):pass

    def test_plan_from_frozen_mock_sidecars(self):
        with tempfile.TemporaryDirectory() as folder:
            c={'results':{'d1':mkdoc(1),'d2':mkdoc(2,'PARTIAL'),
                          'd3':mkdoc(3,'UNAVAILABLE',hash=False)}}
            t={'runs':{},'reviews':{'r1':review(1)}}
            def get_sidecar(commit,name,cache):
                self.assertEqual(commit,'c'*40)
                return c if name=='future-candidates.json' else t
            with (patch.object(f.base,'github_head',return_value='c'*40),
                  patch.object(f.base,'get_sidecar',side_effect=get_sidecar)):
                result=f.obtain_plan(Path(folder))
            self.assertEqual(len(result['items']),2)
            self.assertTrue(f.valid_plan(result))
            self.assertEqual(result['snapshot_commit'],'c'*40)
            # Repeated starts must not try a changed GitHub branch.
            with patch.object(f.base,'github_head',side_effect=RuntimeError('MUST_NOT_FETCH_AGAIN')):
                self.assertEqual(f.obtain_plan(Path(folder))['plan_sha256'],result['plan_sha256'])

    def test_readonly_title_is_not_model_evidence(self):
        self.assertIn('DEMAND',f.title_only_hints('Large supplier wins new contract'))
        self.assertEqual(f.title_only_hints('A visiting celebrity'),[])



if __name__=='__main__':unittest.main()

