@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0."
set "PYTHONUTF8=1"
where py >nul 2>nul
if errorlevel 1 goto USE_PYTHON
py -3 "%~dp0bct_fullscan.py" --export
goto END
:USE_PYTHON
python "%~dp0bct_fullscan.py" --export
:END
pause
