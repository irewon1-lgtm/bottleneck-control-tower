@echo off
setlocal
set "TARGET=%LOCALAPPDATA%\BCTpilot\fullscan"
if not exist "%TARGET%" (
 echo No result folder yet. Run START_ALL.bat first.
 pause
 exit /b 1
)
start "" "%TARGET%"
